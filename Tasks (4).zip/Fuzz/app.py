from flask import Flask, jsonify, render_template
import os
from dotenv import load_dotenv

# Загрузка переменных окружения из .env файла
load_dotenv()

app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'your_default_secret_key')
flag = os.getenv('FLAG', 'default_flag')

# Функция для проверки пути фаззинга
def is_fuzzing_path(path):
    expected_path = "/f/l/a/g/1/3/3/7"
    return path == expected_path
@app.route('/')
def index():
    return render_template('index.html')
# Маршрут для фаззинга
@app.route('/<path:path>', methods=['GET'])
def fuzz(path):
    full_path = f"/{path}"
    if is_fuzzing_path(full_path):
        return jsonify({"flag": flag})
    else:
        return "Try harder!", 404

if __name__ == '__main__':
    app.run(debug=True, host="0.0.0.0", port=5004)
