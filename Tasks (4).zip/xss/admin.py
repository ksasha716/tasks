import time
import requests
from selenium import webdriver
from selenium.webdriver.chrome.service import Service as ChromeService
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager

# Устанавливаем куки с флагом
admin_cookies = {'session': 'admin_session_cookie', 'cookie': 'zssoib{Y0ur_XSS_fl@g_muSt_B3_S0me_Wh3r3_H3r3?}'}

# Словарь для хранения времени последнего посещения сессии
last_visited = {}

# Интервал между посещениями одной и той же сессии (в секундах)
visit_interval = 120  # 2 минуты

# Настройка параметров для запуска браузера в фоновом режиме
chrome_options = Options()
chrome_options.add_argument("--headless")
chrome_options.add_argument("--disable-gpu")
chrome_options.add_argument("--no-sandbox")
chrome_options.add_argument("--disable-dev-shm-usage")

while True:
    # URL для получения списка активных сессий
    list_sessions_url = 'http://127.0.0.1:5003/list_sessions'
    
    # Получение списка активных сессий
    response = requests.get(list_sessions_url)
    session_ids = response.json().get("sessions", [])

    current_time = time.time()
    for session_id in session_ids:
        # Проверка, прошло ли достаточно времени с момента последнего посещения
        if current_time - last_visited.get(session_id, 0) < visit_interval:
            continue

        url = f'http://127.0.0.1:5003/session/{session_id}'
        driver = webdriver.Chrome(service=ChromeService(ChromeDriverManager().install()), options=chrome_options)
        
        # Устанавливаем куки с флагом для каждого запроса
        driver.get(url)
        for name, value in admin_cookies.items():
            driver.add_cookie({'name': name, 'value': value})
        
        driver.get(url)
        print(f'Admin visited the page for session {session_id} successfully.')
        last_visited[session_id] = current_time  # Обновление времени последнего посещения
        
        # Ожидание перед закрытием браузера
        time.sleep(10)
        driver.quit()

    # Очистка неактивных сессий (например, если не было новых сообщений более часа)
    inactive_sessions = [sid for sid, last_time in last_visited.items() if current_time - last_time > 3600]
    for sid in inactive_sessions:
        del last_visited[sid]

    # Ожидание перед следующей итерацией
    time.sleep(10)
