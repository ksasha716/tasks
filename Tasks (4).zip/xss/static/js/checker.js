// ALl rights on the script belongs to http://prompt.ml/

$(function() {

    var YOU_WON = [
        '__     ______  _    _  __          ______  _   _ ',
        '\\ \\   / / __ \\| |  | | \\ \\        / / __ \\| \\ | |',
        ' \\ \\_/ / |  | | |  | |  \\ \\  /\\  / / |  | |  \\| |',
        '  \\   /| |  | | |  | |   \\ \\/  \\/ /| |  | | . ` |',
        '   | | | |__| | |__| |    \\  /\\  / | |__| | |\\  |',
        '   |_|  \\____/ \\____/      \\/  \\/   \\____/|_| \\_|'
    ].join('\n');

    var isWon = false;
    var originSource;
    var solvedURL = $('#name').attr("x-url");

    // Get message from iframe
    $(window).on('message', function(e) {
        if (e.originalEvent.origin != 'http://xss.school.sibears.ru') {
		return false
	    }
        var data = e.originalEvent.data;
        if (!isWon && data.passed) {
            isWon = true;
            originSource = $('#escape-func').text();
            $('#escape-func').text(YOU_WON);
             $.post(solvedURL, {
                name: localStorage.name,
                code: data.code
            });
        }
    });

    // Post function code to <pre> tags
    $('#escape-func').text(
        $('#unsafe-script').text()
                           .replace(/^\n|\n$/g, '')
                           .replace(/<\\\/script>/g, '</script> ')
    );
    // Highlight it
    $('pre code').each(function(i, block) {
        hljs.highlightBlock(block);
    });


    var sandbox = new Sandbox($('#sandbox-frame').attr("x-url"));
    $('#sandbox-frame').append(sandbox.getFrame());

    // Get the name and store it
     $('#name').on('input', function(e) {
        var name = $(this).val();
        localStorage.name = name;
    }).val(localStorage.name);

    // Input on change
    $('#input').on('input', function(e) {
        var input = $(this).val();
        var html = escape(input);

        $('#injected-html').text(html);
        sandbox.inject(JSON.stringify({input: input, html: html}));
    });



});

////////////////////////////////////////////////////////////////////////////////

function Sandbox(src) {
    var self = this;
    self.script = '';
    self.src = src;

    this.frame = $('<iframe></iframe>').attr({
        'scrolling': "no"
    })/*.on('load', function(e) {
        try {
            this.contentWindow.name; // IE
            this.contentWindow.name = self.script;
            this.contentWindow.location = src;
        } catch (e) {}
    });*/
}

Sandbox.prototype.renew = function() {
	this.frame[0].contentWindow.name; // IE
        this.frame[0].contentWindow.name = this.script;
        this.frame[0].contentWindow.location = this.src;

};


Sandbox.prototype.getFrame = function() {
    return this.frame;
};

Sandbox.prototype.inject = function(script) {
    var frame = this.frame[0];

    this.script = script;
    //frame.contentWindow.location = 'about:blank';
    this.renew();
};