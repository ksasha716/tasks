from flask import Flask, request, render_template, session, redirect
import os
from dotenv import load_dotenv
from datetime import timedelta
import subprocess
import sys

# Загрузка переменных окружения из .env файла
load_dotenv(os.path.join(os.path.dirname(__file__), '.env'))

app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'your_default_secret_key')

active_sessions = {}

@app.before_request
def make_session_permanent():
    session.permanent = True
    app.permanent_session_lifetime = timedelta(hours=1)
    if 'uid' not in session:
        session['uid'] = os.urandom(16).hex()
    active_sessions[session['uid']] = active_sessions.get(session['uid'], [])

@app.route('/')
def index():
    uid = session.get('uid')
    messages = active_sessions.get(uid, [])
    return render_template('xss.html', messages=messages)

@app.route('/post_message', methods=['POST'])
def post_message():
    message = request.form.get('message')
    if message:
        uid = session.get('uid')
        if uid:
            messages = active_sessions[uid]
            messages.append(message)
    return redirect('/')

@app.route('/list_sessions')
def list_sessions():
    return {"sessions": list(active_sessions.keys())}

@app.route('/session/<session_id>')
def session_view(session_id):
    messages = active_sessions.get(session_id, [])
    return render_template('xss.html', messages=messages)

if __name__ == '__main__':
    current_dir = os.path.dirname(os.path.abspath(__file__))
    admin_path = os.path.join(current_dir, 'admin.py')

    # Запуск admin.py в фоновом режиме с использованием правильного интерпретатора Python
    subprocess.Popen([sys.executable, admin_path], env=os.environ.copy())

    app.run(debug=True, host="0.0.0.0", port=5010)
